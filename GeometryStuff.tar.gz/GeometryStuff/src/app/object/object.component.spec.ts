/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ObjectComponent } from './object.component';

describe('Component: Object', () => {
  it('should create an instance', () => {
    let component = new ObjectComponent();
    expect(component).toBeTruthy();
  });
});
