/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CodeComponent } from './code.component';

describe('Component: Code', () => {
  it('should create an instance', () => {
    let component = new CodeComponent();
    expect(component).toBeTruthy();
  });
});
