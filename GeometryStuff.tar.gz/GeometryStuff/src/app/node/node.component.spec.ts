/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { NodeComponent } from './node.component';

describe('Component: Node', () => {
  it('should create an instance', () => {
    let component = new NodeComponent();
    expect(component).toBeTruthy();
  });
});
